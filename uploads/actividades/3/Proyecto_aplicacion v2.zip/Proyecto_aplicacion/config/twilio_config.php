<?php
// Archivo: config/twilio_config.php
return [
    'account_sid' => 'AC5e367ba320be4c039f269d030fd98322', // Tu SID actual
    'auth_token' => '5c67c9620f424f8e5ee5f37f27f74a53',    // Tu token actual
    'whatsapp_from' => 'whatsapp:+14155238886' // Tu número de WhatsApp
];
?>