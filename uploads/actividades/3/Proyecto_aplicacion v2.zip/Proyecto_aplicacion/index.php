<?php
// Redirige automáticamente al login al acceder al servidor
header("Location: views/general/login.php");
exit();
?>